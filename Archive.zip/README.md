# Hackaton da Tractian

 - Observações
## Manutentor
1 - Áudio do chefe - Pode ser usado uma IA que como entrada tenha o que o chefe queira comunicar, do jeito que for mais conveniente para ele (como um áudio, por exemplo), e simplifique ao máximo para o manutentor, além de listar para ele as ferramentas necessárias (seja por acesso ao banco de dados ou internet), capte os códigos das ferramentas necessárias, "converse" com o banco de dados do almoxarifado, e obtenha para o manutentor a reserva de tudo o que será necessário, caso disponivel, e caso não tenha algo disponível, faça a devida reserva. Além disso seria interessante que também obtivesse o acesso a algum tuturial sobre o trabalho que deva ser exercido.


## Planejador
1 - Uma IA pré-treinada com os manuais, documentações, EPI's e demais regras para que ao usuário inserir os detalhes da operação, obtenha o que será necessário.

2 - Uma IA que seja alimentada com as escalações passadas e o planejamento das futuras de cada funcionário, para manter no limite do possível, uma escala dentro da aceitação dos funcionários (e que também receba observações, por exemplo, desempenho, algumas faltas de comportamento dos funcionário, etc. para poder entrar no balanceamento)

3 - Uma IA que una os dados do final do dia e faça relatórios que sejam resumidos para que uma pessoa possa ler e entender o que está acontecendo de maneira mais rápida